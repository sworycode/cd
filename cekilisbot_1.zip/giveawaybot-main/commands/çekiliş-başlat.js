const { Client, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "çekiliş-başlat",
  description: "Bir çekiliş oluşturursun!",
  type: 1,
  options: [],

  run: async(client, interaction) => {

    //ne oldu canim bir sey bulamadin mi heyt amina kodugumm

  }

};
